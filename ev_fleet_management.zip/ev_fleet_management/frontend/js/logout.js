// logout.js

document.getElementById('logoutButton').addEventListener('click', function() {
    // Clear session data (e.g., JWT token) from storage
    localStorage.removeItem('token'); // Remove JWT or session token if stored

    // Optionally clear other user-related data if needed
    localStorage.removeItem('userRole'); // Remove user role if stored separately

    // Redirect to the login page
    window.location.href = 'login.html';
});
