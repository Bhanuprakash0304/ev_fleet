document.getElementById('loginForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const emailError = document.getElementById('emailError');
    const passwordError = document.getElementById('passwordError');
    const messageDiv = document.getElementById('generalError'); // General error message container

    // Reset error messages
    emailError.textContent = "";
    passwordError.textContent = "";
    if (messageDiv) messageDiv.textContent = ""; // Clear general error message

    // Basic validation
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email.match(emailPattern)) {
        emailError.textContent = "Please enter a valid email!";
        return;
    }

    if (password.length < 8) {
        passwordError.textContent = "Password must be at least 8 characters!";
        return;
    }

    try {
        // Send a POST request to the backend API to log in
        const response = await fetch('http://localhost:5000/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });

        const data = await response.json();

        if (response.ok) {
            // Redirect based on user role
            if (data.role === 'fleet_manager') {
                window.location.href = 'fleet_manager.html';
            } else if (data.role === 'driver') {
                window.location.href = 'driver.html';
            } else {
                // Display error if role is unrecognized
                if (messageDiv) {
                    messageDiv.textContent = "Access Denied: Unrecognized role";
                    messageDiv.style.color = "red";
                }
            }
        } else {
            // Display error message from the server if login fails
            if (data.message) {
                messageDiv.textContent = data.message;
                messageDiv.style.color = "red";
            } else {
                messageDiv.textContent = "Login failed. Please check your credentials.";
                messageDiv.style.color = "red";
            }
        }
    } catch (error) {
        console.error('Error:', error);
        messageDiv.textContent = 'An error occurred. Please try again later.';
        messageDiv.style.color = "red";
    }
});

// Toggle password visibility
const passField = document.querySelector('.pass-key');
const showBtn = document.querySelector('.show');

showBtn.addEventListener('click', function() {
    if (passField.type === "password") {
        passField.type = "text";
        showBtn.textContent = "HIDE";
        showBtn.style.color = "#3498db";
    } else {
        passField.type = "password";
        showBtn.textContent = "SHOW";
        showBtn.style.color = "#222";
    }
});
