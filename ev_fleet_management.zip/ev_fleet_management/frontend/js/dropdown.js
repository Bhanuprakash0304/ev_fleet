document.addEventListener("DOMContentLoaded", function() {
    const distributionsButton = document.getElementById("distributionsButton");
    const dropdownContainer = document.getElementById("dropdownContainer");
    const distributionSelect = document.getElementById("distribution-select");
    const imageContainer = document.getElementById("imageContainer");

    // Toggle visibility of dropdown on button click
    distributionsButton.addEventListener("click", function() {
        if (dropdownContainer.style.display === "none") {
            dropdownContainer.style.display = "block"; // Show dropdown
        } else {
            dropdownContainer.style.display = "none"; // Hide dropdown
        }
    });

    // Function to open a specific tab
    window.openTab = function(tabName) {
        const tabContents = document.querySelectorAll(".tab-content");
        tabContents.forEach(content => content.classList.remove("active"));

        const tabButtons = document.querySelectorAll(".tab-btn");
        tabButtons.forEach(button => button.classList.remove("active"));

        document.getElementById(tabName).classList.add("active");
        const activeTabButton = Array.from(tabButtons).find(button => button.textContent.trim().toLowerCase() === tabName.toLowerCase());
        if (activeTabButton) {
            activeTabButton.classList.add("active");
        }
    };

    // Function to show the corresponding image when a dropdown option is selected
    window.showImage = function() {
        const selectedValue = distributionSelect.value;

        // Hide all images inside the image container
        const allImages = imageContainer.querySelectorAll("img");
        allImages.forEach(image => {
            image.style.display = "none";
        });

        // Show the selected image if the value matches an ID
        if (selectedValue) {
            const selectedImage = document.getElementById(`${selectedValue}Image`);
            if (selectedImage) {
                selectedImage.style.display = "block";
                imageContainer.style.display = "block"; // Show container
            }
        } else {
            imageContainer.style.display = "none"; // Hide container if no selection
        }
    };
});
