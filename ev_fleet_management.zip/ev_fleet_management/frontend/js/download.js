document.addEventListener("DOMContentLoaded", function() {
    // Get the download button and Dataset tab
    const downloadButton = document.getElementById("downloadButton");

    // Trigger the download button when the Dataset tab is opened
    window.openTab = function(tabName) {
        // If the Dataset tab is selected, show the download button
        if (tabName === "tab2") {
            downloadButton.style.display = "inline-block"; // Show download button
        } else {
            downloadButton.style.display = "none"; // Hide download button
        }
    };

    // Dataset Download Functionality
    downloadButton.addEventListener("click", function() {
        const datasetUrl = "../assets/dataset.csv"; // Path to your dataset file
        const link = document.createElement("a");

        // Ensure the link is not broken
        if (datasetUrl) {
            // Set the download link
            link.href = datasetUrl;
            link.download = "dataset.csv"; // Specify the name of the downloaded file

            // Append the link to the body (it needs to be part of the DOM to work in some browsers)
            document.body.appendChild(link);

            // Programmatically click the link to trigger the download
            link.click();

            // Clean up the DOM by removing the link after clicking
            document.body.removeChild(link);
        } else {
            console.error("Dataset URL not found");
        }
    });
});
